# ringve-musikkmuseum

Dette er en skriftlig eksampensoppgave i IT2 fra våren 2018. Dere skal jobbe i par med oppgaven. Oppgaveteksten finner dere i fila [IT2-e-18V.pdf](https://github.com/Heimdal-IT/ringve-musikkmuseum/blob/main/IT2_e_18V.pdf), og vedlegg til eksamen (det vil si filer dere skal bruke i besvarelsen deres) finner dere i fila [V2018-museum-filer.zip](https://github.com/Heimdal-IT/ringve-musikkmuseum/blob/main/V2018-Museum-filer.zip).

Dere kommer til å få bruk for å redigere lyd og bilder i oppgaven. Til lydredigering kan dere bruke gratisprogrammet [Audacity](https://www.audacityteam.org/), og til bilderedigering kan dere bruke Paint, [Pixlr](https://pixlr.com/no/), [GIMP](https://www.gimp.org/), eller Photoshop, om dere har det.
